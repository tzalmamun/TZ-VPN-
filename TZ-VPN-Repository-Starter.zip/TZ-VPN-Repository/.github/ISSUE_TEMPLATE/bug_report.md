---
name: Bug report
about: Report a reproducible problem
title: "[Bug] "
labels: bug
---

## App version
## Android version and device
## Steps to reproduce
1.
2.
3.

## Expected behavior

## Actual behavior

## Logs (remove personal data and secrets)

**Do not attach VPN configuration files, private keys, QR codes, passwords, or other secrets.**
